async function fetchJSON(path){
  const res = await fetch('../api'+path);
  return res.json();
}
(async ()=>{
  const root = document.getElementById('root');
  const tbl = document.createElement('table'); tbl.className='table';
  tbl.innerHTML = '<thead><tr><th>Name</th><th>Status</th><th>Start</th><th>End</th><th>Budget</th></tr></thead><tbody></tbody>';
  root.appendChild(tbl);
  const tbody = tbl.querySelector('tbody');
  const rows = await fetchJSON('/projects.json');
  rows.forEach(p=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${p.name}</td><td>${p.status}</td><td>${p.start}</td><td>${p.end}</td><td>$${p.budget.toLocaleString()}</td>`;
    tbody.appendChild(tr);
  })
})();
