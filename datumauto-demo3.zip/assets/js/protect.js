(function(){
  if(!sessionStorage.getItem('da_token')){
    window.location.replace('../index.html');
  }
  const logoutBtn = document.getElementById('logoutBtn');
  if(logoutBtn){ logoutBtn.onclick = ()=>{ sessionStorage.clear(); window.location.href='../index.html'; } }
})();
