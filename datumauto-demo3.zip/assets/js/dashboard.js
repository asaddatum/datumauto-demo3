async function fetchJSON(path){
  const res = await fetch('../api'+path);
  return res.json();
}
(async ()=>{
  const root = document.getElementById('root');
  const stats = await fetchJSON('/stats.json');
  const cards = document.createElement('div'); cards.className='cards';
  const items = [
    {label:'Total Projects', value: stats.projects},
    {label:'Active Tasks', value: stats.active_tasks},
    {label:'BIM Requests', value: stats.requests},
    {label:'Avg. Completion', value: stats.avg_completion+'%'}
  ];
  items.forEach(i=>{ const c=document.createElement('div'); c.className='card2'; c.innerHTML=`<h3>${i.label}</h3><div class="stat">${i.value}</div>`; cards.appendChild(c); });
  root.appendChild(cards);
  const panel=document.createElement('section'); panel.className='panel'; panel.innerHTML='<h3>Recent Activity</h3><div id="activity" class="list"></div>';
  root.appendChild(panel);
  const act = await fetchJSON('/activity.json');
  const ul = document.getElementById('activity');
  act.forEach(a=>{ const d=document.createElement('div'); d.textContent = a; ul.appendChild(d); });
})();
