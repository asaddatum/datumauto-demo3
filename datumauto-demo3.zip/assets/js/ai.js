(function(){
  const root = document.getElementById('root');
  const box = document.createElement('div'); box.className='chat';
  box.innerHTML = '<div id="chatLog" class="chat-log"></div><div class="chat-send"><input id="chatInput" placeholder="Ask about projects, tasks, clashes..."/><button id="sendBtn">Send</button></div>';
  root.appendChild(box);
  const log = document.getElementById('chatLog');
  const input = document.getElementById('chatInput');
  const send = document.getElementById('sendBtn');
  function add(role,text){const d=document.createElement('div'); d.className='msg'; d.innerHTML=`<b>${role}:</b> ${text}`; log.appendChild(d); log.scrollTop=log.scrollHeight;}
  add('BIM Bot','Hello Asad! (Demo3) Ask me about models, tasks, clashes, or schedules.');
  send.onclick = ()=>{ const q=input.value.trim(); if(!q) return; add('You',q); input.value=''; setTimeout(()=>add('BIM Bot','(demo) All systems look healthy. Try: "Show active projects".'),500); };
})();
