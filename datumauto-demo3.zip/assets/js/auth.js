(function(){
  const form = document.getElementById('loginForm');
  if(!form) return;
  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const email = document.getElementById('email').value.trim();
    const pwd = document.getElementById('password').value;
    if(email.toLowerCase()==='admin@datumauto.com' && pwd==='demo123'){
      sessionStorage.setItem('da_token','demo');
      window.location.href='app/dashboard.html';
    } else {
      alert('Invalid demo credentials. Use admin@datumauto.com / demo123');
    }
  });
})();
