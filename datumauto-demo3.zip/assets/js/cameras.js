(async ()=>{
  const root = document.getElementById('root');
  const grid = document.createElement('div'); grid.className='grid'; root.appendChild(grid);
  const cams = [
    {name:'Workstation-01', status:'Recording'},
    {name:'Workstation-02', status:'Active'},
    {name:'QA-QC-01', status:'Idle'},
    {name:'Coordinator-Desk', status:'Active'}
  ];
  cams.forEach(c=>{ const el=document.createElement('div'); el.className='cam'; el.innerHTML=`<div class="thumb"></div><div><b>${c.name}</b></div><div style="color:#9aa4b2">${c.status}</div>`; grid.appendChild(el); });
})();
